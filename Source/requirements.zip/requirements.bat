venv8\Scripts\pip install -r requirements.txt 

rem venv8\Scripts\pip freeze > requirements.txt 

rem venv8\Scripts\python -m pip install --upgrade pip
rem venv8\Scripts\pip --version

